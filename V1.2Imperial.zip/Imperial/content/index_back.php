<html id="html">
    <head>

     <!-- Place your favicon.ico and apple-touch-icon.png in the template root directory -->
  <link href="favicon.ico" rel="shortcut icon">
  
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet"> 
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Parisienne&display=swap" rel="stylesheet">

  <!--부트스트랩-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  
  <!-- Bootstrap CSS File -->
  <link href="../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  
  <!-- Libraries CSS Files -->
  <link href="../css/font.css" rel="stylesheet">
  <link href="../lib/animate-css/animate.min.css" rel="stylesheet">
  
  <!-- Main Stylesheet File -->
  <link href="../css/mainstyle.css" rel="stylesheet">

   <!--button css-->
   <link rel="stylesheet" href="../css/button.css">
  
    <script type="text/javascript" src="http://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="http://code.jquery.com/jquery-latest.js"></script>
        <script>
            function get_page_data()
            {
                var data = $("#page_no").val();
                $.ajax({
                    url: '/team_pro/imperial/php/get_api.php',
                    type: 'GET', //통신 방식을 지정합니다
                    data: {data:data},
                    dataType: 'xml',//서버로부터 받을 데이터 타입을 입력합니다.
                    success: function (msg) { // 통신 성공시 호출해야할 함수
                        var infoList = ``;
                        $(msg).find('item').each(function(index, item){
                            infoList += `
                            <tr>
                                <td style="color: black; text-align: center;">${$(this).find('airline').text()}</td>
                                <td style="color: black; text-align: center;">${$(this).find('airport').text()}</td>
                                <td style="color: black; text-align: center;">${$(this).find('airportCode').text()}</td>
                                <td style="color: black; text-align: center;">${$(this).find('flightId').text()}</td>
                                <td style="color: black; text-align: center;">${$(this).find('remark').text()}</td>
                                <td style="color: black; text-align: center;">${$(this).find('scheduleDateTime').text()}</td>
                            </tr>
                            `;
                            $('#info').empty().append(infoList);
                            $('tr:first').css('background', 'black').css('color', 'white')
                        });//end each
                    },
                    error: function (xhr, status, msg) { // 통신 실패시 호출해야하는 함수
                        console.log('상태값 : ' + status + ' Http에러메시지 : ' + msg);
                        document.write('상태값 : ' + status + '<br> Http에러메시지 : ' + msg);
                    },
                });
            }
            var page_no = 1;
            function get_city_data()
            {
                var data = $("#city_name").val();
                $.ajax({
                    url: '/team_pro/imperial/php/get_api.php',
                    type: 'GET', //통신 방식을 지정합니다
                    data: {data:page_no},
                    dataType: 'xml',//서버로부터 받을 데이터 타입을 입력합니다.
                    success: function (msg) { // 통신 성공시 호출해야할 함수
                        var infoList = ``;
                        var count = 0;
                        $(msg).find('item').each(function(index, item){
                            if($(this).find('airport').text()==data)
                            {
                                infoList += `
                            <tr>
                                <td style="color: black; text-align: center;">${$(this).find('airline').text()}</td>
                                <td style="color: black; text-align: center;">${$(this).find('airport').text()}</td>
                                <td style="color: black; text-align: center;">${$(this).find('airportCode').text()}</td>
                                <td style="color: black; text-align: center;">${$(this).find('flightId').text()}</td>
                                <td style="color: black; text-align: center;">${$(this).find('remark').text()}</td>
                                <td style="color: black; text-align: center;">${$(this).find('scheduleDateTime').text()}</td>
                            </tr>
                                `;
                            }
                            else{
                                if(count == 9 && page_no <= 95)
                                {
                                    page_no++;
                                    //alert($(this).find('cityKor').text());
                                    get_city_data();
                                }
                                else{
                                    count++;
                                }
                            }
                            
                            $('#info').empty().append(infoList);
                            $('tr:first').css('background', 'black').css('color', 'white')
                        });//end each
                    },
                    error: function (xhr, status, msg) { // 통신 실패시 호출해야하는 함수
                        console.log('상태값 : ' + status + ' Http에러메시지 : ' + msg);
                        document.write('상태값 : ' + status + '<br> Http에러메시지 : ' + msg);
                    },
                });
            }
        </script>

        <style>
        .container {
        padding-right: 15%;
        padding-left: 15%;
        margin-right: auto;
        margin-left: auto;
        width: 90%;
    }
    .select{
        width: 8.5%;
        height: 5%;
        background-color: rgb(138, 175, 199);
        color: white;
        border-style: none;
        border-radius: 10%;
        position: absolute;
        top: 40%;
        right: 5.5%;
    }
    .select1{
        width: 8.5%;
        height: 5%;
        background-color: rgb(138, 175, 199);
        color: white;
        border-style: none;
        border-radius: 10%;
        position: absolute;
        top: 45.77%;
        right: 5.5%;
    }
    .select:hover{
        background-color: rgb(163, 209, 205);
    }
    .select1:hover{
        background-color: rgb(163, 209, 205);
    }
    #city_name{
        position: absolute;
        top: 45.77%;
        left: 40.12%;

    }
    #page_no{
        position: absolute;
        left: 40.12%
    }
    #hero .hero-container {
  background: rgba(0, 0, 0, 0.2);}
    
  .btn_inner {
    width: 90px;
    position: absolute;
    right: 5%;
    top: 5%;
    float:left;
    /* display:inline-block; */
    }  

        </style>
    

    <head>
    <script src="/js/timer.js"></script>
<script>
	document.getElementById("html").addEventListener("mousedown", function () {
		SetTime = 300;
    });
</script>
    <body>
    <div id="preloader"></div>
  
  <!--==========================
    Hero Section
  ============================-->
    <section id="hero">
      <div class="hero-container">

       <!-- <div class="logo_inner">
        <img src="../img/logo_air.png" width="100" >
      </div> -->
      <div class="btn_inner">            
        <div><img src="../img/timer.png" width="60"><h2 id="ViewTimer" style="color: black; margin: 0px;"></h1></div>
        <!-- <h1><div id="ViewTimer"></div></h1> -->
      </div>
      <img src="../img/logo_air.png" alt="" style="position: absolute; top: 3.3%; left: 4%; width: 8%;">
  <center>
        <img src="../img/airplane_icon1.png" alt="" style="position: absolute; top:17.5%; right: 35%; width: 4.8%">
        <h1 style="color: black; position: absolute; top: 14.5%; left: 50%; transform: translateX(-50%);">대한항공 운행스케줄</h1>
        <br><br><br><br><br>
        <button type="button" class="btn btn-secondary btn-lg" style="position:absolute; top: 26.5%; left: 45%; transform: translateX(-50%)" onclick="location.href=''">한국어</button>
            <button type="button" class="btn btn-secondary btn-lg" style="position:absolute; top: 26.5%; left: 50%; transform: translateX(-50%)" onclick="location.href='index_back_Eng.php'">영어</button>
            <button type="button" class="btn btn-secondary btn-lg" style="position:absolute; top: 26.5%; left: 55%; transform: translateX(-50%)" onclick="location.href='index_back_JP.php'">일본어</button>

            <div style="width: 150%;" align="center">
            <input type="text" id="page_no" style="height: 5%; top:35.5%"/>
            <input type='button' class="select" value='페이지 번호 &gt;' style="position: absolute; left:55%; top:35.5%" onclick="get_page_data(); return false;"/>
            </div>
            <br><br>
            <div style="width:100%;" align="center">
            <input type="text" id="city_name" style="height: 5%; top:41.5%"/>
            <input type='button' class="select1" value='도착지 &gt;' style="position: absolute; left:55%; top:41.5%" onclick="get_city_data(); return false;"/>
            </div>
            
            <br><br><br><br>
        <table class="table_center">
        <tr>            
                <th style="width:17%; color: white; font-size:20px; text-align:center;">항공명</th>
                <th style="width:25%; color: white; font-size:20px; text-align:center;">도착지 공항</th>
                <th style="width:15%; color: white; font-size:20px; text-align:center;">도착지 공항코드</th>
                <th style="width:15%; color: white; font-size:20px; text-align:center;">편명</th>
                <th style="width:12%; color: white; font-size:20px; text-align:center;">상태</th>
                <th style="width:15%; color: white; font-size:20px; text-align:center;">출발예정</th>
            </tr>
            <tbody id="info"></tbody>
        </table>
        </center>
    </div>
    </section>

        <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
   
    
  <!-- Required JavaScript Libraries -->
  <script src="../lib/jquery/jquery.min.js"></script>
  <script src="../lib/bootstrap/js/bootstrap.min.js"></script>
  <script src="../lib/superfish/hoverIntent.js"></script>
  <script src="../lib/superfish/superfish.min.js"></script>
  <script src="../lib/morphext/morphext.min.js"></script>
  <script src="../lib/wow/wow.min.js"></script>
  <script src="../lib/stickyjs/sticky.js"></script>
  <script src="../lib/easing/easing.js"></script>
  
  <!-- Template Specisifc Custom Javascript File -->
  <script src="../js/custom.js"></script>
  
  <script src="../contactform/contactform.js"></script>

    <body>
</html>